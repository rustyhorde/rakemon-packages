complete -c rakemon -l listen -d 'UDP address to listen on for cargo-rake lifecycle events' -r
complete -c rakemon -s h -l help -d 'Print help'
complete -c rakemon -s V -l version -d 'Print version'
