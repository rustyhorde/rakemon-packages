# rakemon

Terminal dashboard for `cargo-rake` lifecycle events.

`rakemon` listens on a UDP socket for JSON lifecycle events emitted by
[`cargo-rake`](https://crates.io/crates/librake) (via the `librake` crate) and
renders them live as a `ratatui`/`crossterm` TUI: one tab per project, one
sub-tab per run (`before_all`/`after_all` cycle), and a table of target rows
with a spinner, status icon, elapsed time, and current step. A bottom info
bar cycles through Compact, Detailed, and Activity verbosity modes.

## License

`rakemon` is proprietary software — see [`LICENSE`](LICENSE). It requires a
valid, active `cargo-rake` license covering the `events` feature (without
one, `cargo-rake` never emits the lifecycle events this dashboard listens
for).

## Installation

### From source

```sh
cargo build
# or, to install the binary onto your PATH:
cargo install --path rakemon --force --locked
```

### Pre-built packages

Once a release has been published (see `scripts/release/RUNBOOK.md`), binaries
are also available from the public
[`rustyhorde/rakemon-packages`](https://github.com/rustyhorde/rakemon-packages)
mirror — `rustyhorde/rakemon` itself stays private, so packages are always
built from a pre-compiled binary, never from source.

#### Arch Linux (AUR)

```sh
yay -S rakemon-bin   # or rakemon-unstable-bin
```

`rakemon-unstable-bin` conflicts with `rakemon-bin` (the `unstable` feature
is a functional no-op — it only toggles nightly-only lint gates), so only one
can be installed at a time.

#### Debian/Ubuntu (`apt`)

The signed apt repository at
<https://rustyhorde.github.io/rakemon-packages/> tracks every release, so
`apt upgrade` keeps `rakemon` current. Packages are available for `amd64` and
`arm64`:

```bash
sudo install -d /etc/apt/keyrings
curl -fsSL https://rustyhorde.github.io/rakemon-packages/gpg.key \
    | sudo gpg --dearmor -o /etc/apt/keyrings/rakemon.gpg

echo "deb [arch=amd64,arm64 signed-by=/etc/apt/keyrings/rakemon.gpg] \
  https://rustyhorde.github.io/rakemon-packages/apt stable main" \
    | sudo tee /etc/apt/sources.list.d/rakemon.list

sudo apt update
sudo apt install rakemon
```

#### Fedora/RHEL (`dnf`)

```bash
sudo dnf config-manager \
    --add-repo https://rustyhorde.github.io/rakemon-packages/rpm/rakemon.repo
sudo dnf install rakemon
```

#### macOS (Apple Silicon)

Intel Macs are not currently supported.

```bash
brew tap rustyhorde/rakemon
brew install rakemon
```

## Usage

```sh
cargo run -p rakemon -- --listen 127.0.0.1:9999   # 127.0.0.1:9999 is also the default
```

Once running, configure `cargo-rake` (via a Rakefile's `[lifecycle]
address`, or anything emitting the same JSON lifecycle events) to send its
events to the address `rakemon` is bound to — `rakemon` never initiates a
connection to `cargo-rake`, it only receives — and the dashboard populates
live.

Only one *default* (loopback) `rakemon` process may run at a time —
starting a second instance prints an error and exits immediately rather
than racing the first for the shared state file. Read-only instances
(any non-loopback `--listen` address; see below) skip that shared state
entirely, so any number of them can run at once, including alongside the
one stateful instance.

Key bindings: `j`/`k` to move the row cursor in a run's target table, `gg`/`G`
to jump to top/bottom, `^u`/`^d` for half-page scrolling, `Enter`/`Space` to
expand/collapse a target row's steps, and tab keys to switch between project
and run tabs.

`rakemon -V` / `--version` prints the crate's semver followed by an extended
build/git/rustc/system-info banner (via `vergen-pretty`).

### Remote and multiple viewers

`--listen` is always a LOCAL address this process binds to — not the
address of a remote `cargo-rake` host. Any non-loopback `--listen` address
puts that instance in read-only mode: no local state persistence, no
history on attach, and the `L` (mark run lost) key binding disabled.

**Multicast — one Rakefile config, any number of viewers.** Each viewer
machine runs, e.g.:

```sh
cargo run -p rakemon -- --listen 239.255.7.7:9999
```

and the machine driving the build needs just one `[lifecycle]` entry in
its Rakefile.toml:

```toml
[lifecycle]
address = "239.255.7.7:9999"
```

`239.0.0.0/8` (RFC 2365, administratively scoped) is the right range for
private/local multicast groups. Multicast delivery is normally limited to
the local subnet/broadcast domain unless the network is explicitly
configured for multicast routing — fine for a LAN of dev machines, not
guaranteed across routed networks, VPNs, or most cloud VPCs.

**Relay server — unicast, NAT-friendly (recommended when multicast
doesn't reach).** The primary machine — the one running the real
`cargo-rake` build and holding rakemon's local state — additionally runs a
relay fan-out server alongside its normal `--listen`:

```sh
cargo run -p rakemon -- --listen 127.0.0.1:9999 --serve 0.0.0.0:9100
```

Each remote viewer then attaches with:

```sh
cargo run -p rakemon -- --server <primary-host>:9100
```

`--server` puts that instance in client mode: always read-only, and it
never binds a local UDP listener at all — instead it registers with the
primary's relay server and receives a byte-identical copy of every event
the primary receives on `--listen`. Because the *viewer* connects to the
primary first (unlike multicast, which needs IGMP support on every hop),
typical NAT/firewalls pass the reply traffic through automatically — this
is the option to reach a viewer on a different network, behind NAT, or
over a VPN where multicast doesn't work. The primary's `--serve` port
needs inbound UDP open, same as any other `--listen`/`--serve` address.

**Explicit unicast list — fallback when multicast doesn't reach.** A
Rakefile's `[lifecycle] address` can also be an array, fanning events out
to each listed destination individually:

```toml
[lifecycle]
address = ["127.0.0.1:9999", "10.0.0.42:9999", "10.0.0.57:9999"]
```

with each remote viewer bound to its own routable IP or `0.0.0.0:PORT`.
This needs a `cargo-rake`/`librake` release with multi-destination
`[lifecycle] address` support.

Either way, each viewer's chosen port needs inbound UDP open on that
machine (and, for multicast, IGMP traffic permitted on the LAN).

### Trying it without a real `cargo-rake` run

`librakemon/examples/dev_emit.rs` is a synthetic event generator that sends
real UDP datagrams built from rakemon's own event types, useful for
exercising the TUI manually:

```sh
cargo run -p librakemon --example dev_emit -- --target build --projects 2 --repeat
```

Run it in one terminal and `cargo run -p rakemon` (rakemon itself) in
another, both pointed at the same `--listen`/target address.

## Development

This is a Cargo workspace with three members:

| crate | what it is |
| --- | --- |
| `librakemon` | the library: event types, application state, rendering |
| `rakemon` | the binary: CLI parsing, the UDP listener, the render/input loop |
| `xtask` | dist-artifact generation (man page, shell completions), not shipped |

Build/lint/test/coverage/install for this repo are orchestrated by
[`Rakefile.toml`](Rakefile.toml), consumed by a `cargo-rake`-compatible
runner (not Ruby rake). Key targets:

| target | what it does |
| --- | --- |
| `fmt` | `cargo fmt` (and a `--check` pass) |
| `clippy` | `cargo matrix clippy --all-targets -- -Dwarnings` |
| `build` | `cargo matrix build` (and `--examples`) |
| `test` | `cargo matrix nextest run` |
| `coverage` | `cargo llvm-cov` via nextest, writes `lcov.info` + HTML report |
| `install` | `cargo install --path rakemon --force --locked` |
| `musl` | cross-builds x86_64/aarch64 musl release binaries via Docker |
| `clean` | `cargo clean` (and removes `lcov.info`) |
| `release` | cuts a full release (see below) — manual/opt-in, not part of `most`/`all`/`daily` |
| `most` / `all` / `daily` | aggregates of the above (`release` excluded) |

Run the full pipeline with `rake` (the project's standing convention for
final verification, in place of ad hoc `cargo` commands).

`Rakefile.toml`'s `[lifecycle] address` matches rakemon's own default
`--listen` address, so running the Rakefile-driven build against this repo
while rakemon is listening is itself a live demo of the dashboard.

Equivalent plain `cargo` commands, if you'd rather run things directly:

- Build: `cargo build --workspace`
- Run: `cargo run -p rakemon`
- Test: `cargo test --workspace` (a single test: `cargo test <test_name>`)
- Lint: `cargo clippy --workspace`
- Format: `cargo fmt`

### Release packaging

Releases are cut entirely locally via `cargo rake release` (see
[`scripts/release/RUNBOOK.md`](scripts/release/RUNBOOK.md)) — this private
repo doesn't use GitHub Actions, since private-repo Actions minutes are
tightly rate-limited. The pipeline builds musl binaries, packages DEB/RPM via
`nfpm`, creates a GitHub release, mirrors binaries to the public
`rustyhorde/rakemon-packages` repo, publishes signed APT/RPM repos, and
refreshes/publishes the AUR packages.

`cargo xtask dist rakemon` (or, without the `.cargo/config.toml` alias,
`cargo run --release --locked -p xtask -- dist rakemon`) generates the man
page and bash/zsh/fish completions shipped in every package
(`dist/rakemon/`), from the same `clap::Command` the `rakemon` binary parses
with. It's invoked by `scripts/release/build.fish`, not needed for
day-to-day development.
