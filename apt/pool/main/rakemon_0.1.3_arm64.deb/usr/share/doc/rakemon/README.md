# rakemon

Terminal dashboard for `cargo-rake` lifecycle events.

`rakemon` listens on a UDP socket for JSON lifecycle events emitted by
[`cargo-rake`](https://crates.io/crates/librake) (via the `librake` crate) and
renders them live as a `ratatui`/`crossterm` TUI: one tab per project, one
sub-tab per run (`before_all`/`after_all` cycle), and a table of target rows
with a spinner, status icon, elapsed time, and current step. A bottom info
bar cycles through Compact, Detailed, and Activity verbosity modes.

## License

`rakemon` is proprietary software — see [`LICENSE`](LICENSE). It requires a
valid, active `cargo-rake` license covering the `events` feature (without
one, `cargo-rake` never emits the lifecycle events this dashboard listens
for).

## Installation

### From source

```sh
cargo build
# or, to install the binary onto your PATH:
cargo install --path rakemon --force --locked
```

### Pre-built packages

Once a release has been published (see `scripts/release/RUNBOOK.md`), binaries
are also available from the public
[`rustyhorde/rakemon-packages`](https://github.com/rustyhorde/rakemon-packages)
mirror — `rustyhorde/rakemon` itself stays private, so packages are always
built from a pre-compiled binary, never from source.

#### Arch Linux (AUR)

```sh
yay -S rakemon-bin   # or rakemon-unstable-bin
```

`rakemon-unstable-bin` conflicts with `rakemon-bin` (the `unstable` feature
is a functional no-op — it only toggles nightly-only lint gates), so only one
can be installed at a time.

#### Debian/Ubuntu (`apt`)

The signed apt repository at
<https://rustyhorde.github.io/rakemon-packages/> tracks every release, so
`apt upgrade` keeps `rakemon` current. Packages are available for `amd64` and
`arm64`:

```bash
sudo install -d /etc/apt/keyrings
curl -fsSL https://rustyhorde.github.io/rakemon-packages/gpg.key \
    | sudo gpg --dearmor -o /etc/apt/keyrings/rakemon.gpg

echo "deb [arch=amd64,arm64 signed-by=/etc/apt/keyrings/rakemon.gpg] \
  https://rustyhorde.github.io/rakemon-packages/apt stable main" \
    | sudo tee /etc/apt/sources.list.d/rakemon.list

sudo apt update
sudo apt install rakemon
```

#### Fedora/RHEL (`dnf`)

```bash
sudo dnf config-manager \
    --add-repo https://rustyhorde.github.io/rakemon-packages/rpm/rakemon.repo
sudo dnf install rakemon
```

#### macOS (Apple Silicon)

Intel Macs are not currently supported.

```bash
brew tap rustyhorde/rakemon
brew install rakemon
```

## Usage

```sh
cargo run -p rakemon -- --listen 127.0.0.1:9999   # 127.0.0.1:9999 is also the default
```

Once running, point `cargo-rake` (or anything emitting the same JSON
lifecycle events) at the same address and the dashboard populates live.

Only one `rakemon` process may run at a time, regardless of `--listen`
address — starting a second instance prints an error and exits immediately
rather than racing the first for the shared state file.

Key bindings: `j`/`k` to move the row cursor in a run's target table, `gg`/`G`
to jump to top/bottom, `^u`/`^d` for half-page scrolling, `Enter`/`Space` to
expand/collapse a target row's steps, and tab keys to switch between project
and run tabs.

`rakemon -V` / `--version` prints the crate's semver followed by an extended
build/git/rustc/system-info banner (via `vergen-pretty`).

### Trying it without a real `cargo-rake` run

`librakemon/examples/dev_emit.rs` is a synthetic event generator that sends
real UDP datagrams built from rakemon's own event types, useful for
exercising the TUI manually:

```sh
cargo run -p librakemon --example dev_emit -- --target build --projects 2 --repeat
```

Run it in one terminal and `cargo run -p rakemon` (rakemon itself) in
another, both pointed at the same `--listen`/target address.

## Development

This is a Cargo workspace with three members:

| crate | what it is |
| --- | --- |
| `librakemon` | the library: event types, application state, rendering |
| `rakemon` | the binary: CLI parsing, the UDP listener, the render/input loop |
| `xtask` | dist-artifact generation (man page, shell completions), not shipped |

Build/lint/test/coverage/install for this repo are orchestrated by
[`Rakefile.toml`](Rakefile.toml), consumed by a `cargo-rake`-compatible
runner (not Ruby rake). Key targets:

| target | what it does |
| --- | --- |
| `fmt` | `cargo fmt` (and a `--check` pass) |
| `clippy` | `cargo matrix clippy --all-targets -- -Dwarnings` |
| `build` | `cargo matrix build` (and `--examples`) |
| `test` | `cargo matrix nextest run` |
| `coverage` | `cargo llvm-cov` via nextest, writes `lcov.info` + HTML report |
| `install` | `cargo install --path rakemon --force --locked` |
| `musl` | cross-builds x86_64/aarch64 musl release binaries via Docker |
| `clean` | `cargo clean` (and removes `lcov.info`) |
| `release` | cuts a full release (see below) — manual/opt-in, not part of `most`/`all`/`daily` |
| `most` / `all` / `daily` | aggregates of the above (`release` excluded) |

Run the full pipeline with `rake` (the project's standing convention for
final verification, in place of ad hoc `cargo` commands).

`Rakefile.toml`'s `[lifecycle] address` matches rakemon's own default
`--listen` address, so running the Rakefile-driven build against this repo
while rakemon is listening is itself a live demo of the dashboard.

Equivalent plain `cargo` commands, if you'd rather run things directly:

- Build: `cargo build --workspace`
- Run: `cargo run -p rakemon`
- Test: `cargo test --workspace` (a single test: `cargo test <test_name>`)
- Lint: `cargo clippy --workspace`
- Format: `cargo fmt`

### Release packaging

Releases are cut entirely locally via `cargo rake release` (see
[`scripts/release/RUNBOOK.md`](scripts/release/RUNBOOK.md)) — this private
repo doesn't use GitHub Actions, since private-repo Actions minutes are
tightly rate-limited. The pipeline builds musl binaries, packages DEB/RPM via
`nfpm`, creates a GitHub release, mirrors binaries to the public
`rustyhorde/rakemon-packages` repo, publishes signed APT/RPM repos, and
refreshes/publishes the AUR packages.

`cargo xtask dist rakemon` (or, without the `.cargo/config.toml` alias,
`cargo run --release --locked -p xtask -- dist rakemon`) generates the man
page and bash/zsh/fish completions shipped in every package
(`dist/rakemon/`), from the same `clap::Command` the `rakemon` binary parses
with. It's invoked by `scripts/release/build.fish`, not needed for
day-to-day development.
